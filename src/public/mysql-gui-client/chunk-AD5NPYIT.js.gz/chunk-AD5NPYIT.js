import{$ as a}from"./chunk-4TXQ4VDV.js";import"./chunk-LYBDN2BO.js";export{a as HomeComponent};
